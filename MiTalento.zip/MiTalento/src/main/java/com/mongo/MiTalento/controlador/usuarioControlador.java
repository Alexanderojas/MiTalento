/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mongo.MiTalento.controlador;

import com.mongo.MiTalento.modelo.usuarioModelo;
import com.mongo.MiTalento.repositorio.usuarioRepositorio;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author barpa
 */
@RestController
@CrossOrigin(origins = "*", methods = {RequestMethod.DELETE, RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@RequestMapping("/api/usuario")

public class usuarioControlador {

    @Autowired
    private usuarioRepositorio Repository;

    @PostMapping("/usuario")
    public usuarioModelo crear(@RequestBody @Validated usuarioModelo U) {

        return Repository.insert(U);

    }

     //////Consulta
    @GetMapping("/consulta")
    public List<usuarioModelo> consultarUsuario() {

        return Repository.findAll();
    }
    /////Actualizar

    @PutMapping("/actualizar/{id}")
    public usuarioModelo actualizarUsuario(@PathVariable String id, @RequestBody @Validated usuarioModelo C) {

        return Repository.save(C);
    }
    
    //////Eliminar
    @DeleteMapping("eliminar/{id}")
    public void eliminar(@PathVariable String id) {
        
        Repository.deleteById(id);
    }
    
}

