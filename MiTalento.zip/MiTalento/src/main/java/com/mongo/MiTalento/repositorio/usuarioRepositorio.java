/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mongo.MiTalento.repositorio;

import com.mongo.MiTalento.modelo.usuarioModelo;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author barpa
 */
@Repository
public interface usuarioRepositorio extends MongoRepository<usuarioModelo, String>{
    
}
