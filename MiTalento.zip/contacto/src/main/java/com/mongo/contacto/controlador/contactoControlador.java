/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mongo.contacto.controlador;

import com.mongo.contacto.modelo.contactoModelo;
import com.mongo.contacto.reporitorio.contactoRepositorio;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author barpa
 */
@RestController
@CrossOrigin(origins = "*", methods = {RequestMethod.DELETE, RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@RequestMapping("/api/contacto")

public class contactoControlador {

    @Autowired
    private contactoRepositorio Repository;

    @PostMapping
    public contactoModelo guardar(@RequestBody @Validated contactoModelo P) {

        return Repository.insert(P);
    }

    //////Consulta
    @GetMapping("/consulta")
    public List<contactoModelo> consultarContacto() {

        return Repository.findAll();
    }
    
    //////Consulta individual
    @GetMapping("/consulta/{id}")
    public Optional<contactoModelo> consultarContactoIndividual(@PathVariable String id) {

        return Repository.findById(id);
    }
    /////Actualizar

    @PutMapping("/actualizar/{id}")
    public contactoModelo actualizarContacto(@PathVariable String id, @RequestBody @Validated contactoModelo C) {

        return Repository.save(C);
    }

    //////Eliminar
    @DeleteMapping("eliminar/{id}")
    public void eliminar(@PathVariable String id) {

        Repository.deleteById(id);
    }
}
