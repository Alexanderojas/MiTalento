package com.mongo.contacto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactoApplicationTests {

	@Test
	void contextLoads() {
	}

}
